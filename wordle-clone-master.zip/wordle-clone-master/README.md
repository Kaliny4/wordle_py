# C++ Wordle Clone

Quick and dirty project I made to learn more about ANSI escape sequences and to try to implement a simple wordle clone from scratch

To-Do:
- Refactor (maybe use more STL)
- Add input validation
- Improve UI (especially when an invalid word is entered)
